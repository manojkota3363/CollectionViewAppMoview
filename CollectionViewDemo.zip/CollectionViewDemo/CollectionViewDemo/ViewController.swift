//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by Kota,Manoj on 4/25/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var CollectionViewOutlet: UICollectionView!
    
    @IBOutlet weak var titleOutlet: UILabel!
    
    @IBOutlet weak var YearReleasedOutlet: UILabel!
    
    @IBOutlet weak var RatingOutlet: UILabel!
    
    @IBOutlet weak var BoxOfficeOutlet: UILabel!
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=CollectionViewOutlet.dequeueReusableCell(withReuseIdentifier: "movie", for: indexPath) as! MovieCollectionViewCell
         cell.assignMovie(with: movies[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index:indexPath)
    }
    func assignMovieDetails(index:IndexPath){
        titleOutlet.text = "Movie title:\(movies[index.row].title)"
        YearReleasedOutlet.text="YearReleasedOutlet:\(movies[index.row].releasedYear)"
        RatingOutlet.text="Rating is:\(movies[index.row].movieRating)"
        BoxOfficeOutlet.text="BoxOfficeRating:\(movies[index.row].boxOffice)"
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        CollectionViewOutlet.delegate=self
        CollectionViewOutlet.dataSource=self
    }


}

